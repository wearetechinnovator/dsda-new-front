class QuotationTable{
  id = null;

  constructor(tableId){
    this.id = tableId;
  }

  
  
}